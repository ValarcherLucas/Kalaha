class Regles():
    def __init__(self, int):
        if int == 0:
            pass
        