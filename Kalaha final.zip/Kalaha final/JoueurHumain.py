from Joueur import Joueur
class JoueurHumain(Joueur):
    def __init__(self):
        self.humain = True
